/********************************************************/
/* - Archivo: global.h                                  */
/* - Autores: profesores SOPER                          */
/* - Fecha: 20/04/2020                                  */
/* - Descripcion: archivo con tipos basicos que se usan */
/*   en los diferentes modulos del programa             */
/********************************************************/

#ifndef _GLOBAL_H
#define _GLOBAL_H

/* Type definitions. */

/* Return code for the functions. */
typedef enum {
    OK,
    ERROR
} Status;

/* Boolean values. */
typedef enum {
    FALSE,
    TRUE
} Bool;

#endif
