/*********************************************************/
/* - Archivo: sort.c                                     */
/* - Autores: profesores SOPER                           */
/* - Modificaciones: Jorge de Miguel y Laura de Paz      */
/* - Pareja: 07                                          */
/* - Grupo: 2202                                         */
/* - Fecha: 29/04/2020                                   */
/* - Descripcion: modulo con las funciones mas           */
/*   relevantes del programa. Contiene los algoritmos    */
/*   de ordenacion, el codigo de los trabajadores y del  */
/*   ilustrador y la funcion del padre que coordina todo */
/*********************************************************/

#define _POSIX_C_SOURCE 200112L

#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <mqueue.h>
#include <semaphore.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include "sort.h"
#include "utils.h"


Status bubble_sort(int *vector, int n_elements, int delay) {
    int i, j;
    int temp;

    if ((!(vector)) || (n_elements <= 0)) {
        return ERROR;
    }

    for (i = 0; i < n_elements - 1; i++) {
        for (j = 0; j < n_elements - i - 1; j++) {
            /* Delay. */
            fast_sleep(delay);
            if (vector[j] > vector[j+1]) {
                temp = vector[j];
                vector[j] = vector[j + 1];
                vector[j + 1] = temp;
            }
        }
    }

    return OK;
}

Status merge(int *vector, int middle, int n_elements, int delay) {
    int *aux = NULL;
    int i, j, k, l, m;

    if (!(aux = (int *)malloc(n_elements * sizeof(int)))) {
        return ERROR;
    }

    for (i = 0; i < n_elements; i++) {
        aux[i] = vector[i];
    }

    i = 0; j = middle;
    for (k = 0; k < n_elements; k++) {
        /* Delay. */
        fast_sleep(delay);
        if ((i < middle) && ((j >= n_elements) || (aux[i] < aux[j]))){
            vector[k] = aux[i];
            i++;
        }
        else {
            vector[k] = aux[j];
            j++;
        }

        /* This part is not needed, and it is computationally expensive, but
        it allows to visualize a partial mixture. */
        m = k + 1;
        for (l = i; l < middle; l++) {
            vector[m] = aux[l];
            m++;
        }
        for (l = j; l < n_elements; l++) {
            vector[m] = aux[l];
            m++;
        }
    }

    free((void *)aux);
    return OK;
}

int get_number_parts(int level, int n_levels) {
    /* The number of parts is 2^(n_levels - 1 - level). */
    return 1 << (n_levels - 1 - level);
}

Status init_sort(char *file_name, Sort *sort, int n_levels, int n_processes, int delay) {
    char string[MAX_STRING];
    FILE *file = NULL;
    int i, j, log_data;
    int block_size, modulus;

    if ((!(file_name)) || (!(sort))) {
        fprintf(stderr, "init_sort - Incorrect arguments\n");
        return ERROR;
    }

    /* At most MAX_LEVELS levels. */
    sort->n_levels = MAX(1, MIN(n_levels, MAX_LEVELS));
    /* At most MAX_PARTS processes can work together. */
    sort->n_processes = MAX(1, MIN(n_processes, MAX_PARTS));
    /* The main process PID is stored. */
    sort->ppid = getpid();
    /* Delay for the algorithm in ns (less than 1s). */
    sort->delay = MAX(1, MIN(999999999, delay));

    if (!(file = fopen(file_name, "r"))) {
        perror("init_sort - fopen");
        return ERROR;
    }

    /* The first line contains the size of the data, truncated to MAX_DATA. */
    if (!(fgets(string, MAX_STRING, file))) {
        fprintf(stderr, "init_sort - Error reading file\n");
        fclose(file);
        return ERROR;
    }
    sort->n_elements = atoi(string);
    if (sort->n_elements > MAX_DATA) {
        sort->n_elements = MAX_DATA;
    }

    /* The remaining lines contains one integer number each. */
    for (i = 0; i < sort->n_elements; i++) {
        if (!(fgets(string, MAX_STRING, file))) {
            fprintf(stderr, "init_sort - Error reading file\n");
            fclose(file);
            return ERROR;
        }
        sort->data[i] = atoi(string);
    }
    fclose(file);

    /* Each task should have at least one element. */
    log_data = compute_log(sort->n_elements);
    if (n_levels > log_data) {
        n_levels = log_data;
    }
    sort->n_levels = n_levels;

    /* The data is divided between the tasks, which are also initialized. */
    block_size = sort->n_elements / get_number_parts(0, sort->n_levels);
    modulus = sort->n_elements % get_number_parts(0, sort->n_levels);

    sort->tasks[0][0].completed = INCOMPLETE;
    sort->tasks[0][0].ini = 0;
    sort->tasks[0][0].end = block_size + (modulus > 0);
    sort->tasks[0][0].mid = NO_MID;
    for (j = 1; j < get_number_parts(0, sort->n_levels); j++) {
        sort->tasks[0][j].completed = INCOMPLETE;
        sort->tasks[0][j].ini = sort->tasks[0][j - 1].end;
        sort->tasks[0][j].end = sort->tasks[0][j].ini \
            + block_size + (modulus > j);
        sort->tasks[0][j].mid = NO_MID;
    }
    for (i = 1; i < n_levels; i++) {
        for (j = 0; j < get_number_parts(i, sort->n_levels); j++) {
            sort->tasks[i][j].completed = INCOMPLETE;
            sort->tasks[i][j].ini = sort->tasks[i - 1][2 * j].ini;
            sort->tasks[i][j].mid = sort->tasks[i - 1][2 * j].end;
            sort->tasks[i][j].end = sort->tasks[i - 1][2 * j + 1].end;
        }
    }
    
    /* Inicializamos el semaforo de cada tarea */
    for (i = 0; i < n_levels; i++) {
        for (j = 0; j < get_number_parts(i, sort->n_levels); j++) {
            if (sem_init(&(sort->tasks[i][j].mutex), 1, 1) == -1){ 
                perror("semaforo");
                return ERROR;
            }
        }
    }
    
    return OK;
}

Bool check_task_ready(Sort *sort, int level, int part) {
    if (!(sort)) {
        return FALSE;
    }

    if ((level < 0) || (level >= sort->n_levels) \
        || (part < 0) || (part >= get_number_parts(level, sort->n_levels))) {
        return FALSE;
    }

    if (sort->tasks[level][part].completed != INCOMPLETE) {
        return FALSE;
    }

    /* The tasks of the first level are always ready. */
    if (level == 0) {
        return TRUE;
    }

    /* Other tasks depend on the hierarchy. */
    if ((sort->tasks[level - 1][2 * part].completed == COMPLETED) && \
        (sort->tasks[level - 1][2 * part + 1].completed == COMPLETED)) {
        return TRUE;
    }

    return FALSE;
}


Bool check_nivel_completed(Sort* sort, int level){
    int i;
    int ret;

    if (sort==NULL || level<0)
        return FALSE;

    for (i = 0; i < get_number_parts(level, sort->n_levels); i++){
        sem_wait(&(sort->tasks[level][i].mutex));
        ret = (sort->tasks[level][i].completed == COMPLETED);
        sem_post(&(sort->tasks[level][i].mutex));
        if (ret == FALSE)
            return FALSE;
    }
    return TRUE;
}

Status solve_task(Sort* sort, Task *task) {
    /* In the first level, bubble-sort. */
    if (task->mid == NO_MID) {
        return bubble_sort(\
            sort->data + task->ini, \
            task->end - task->ini, \
            sort->delay);
    }
    /* In other levels, merge. */
    else {
        return merge(\
            sort->data + task->ini, \
            task->mid - task->ini, \
            task->end -  task->ini, \
            sort->delay);
    }
}

/* Manejador SIGALARM */
void manejador_sigalarm(int sig){
    char c;
    alarma = 1;
    
    /* Envia el trabajo que se esta realizando */
    ssize_t nbytes = write(pipe_trab2ilust[WRITE_PIPE], &estado, 3*sizeof(int));
    if(nbytes == -1){
        perror("write");
        exit(EXIT_FAILURE);
    }

    /* Espera a la senhal del ilustrador para continuar*/
    nbytes = read(pipe_ilust2trab[READ_PIPE], &c, sizeof(char));
    if (nbytes == -1){
        perror("read");
        exit(EXIT_FAILURE);
    }

    /* Establece la alarma de nuevo */
    if (alarm(SECS)){
        fprintf(stderr, "Existe una alarma previa establecida\n");
    }
}

Status trabajador(Sort* sort){
    int pos[2];
    Task* task;
    sigset_t set;
    struct sigaction act;

    if (sort==NULL)
        return ERROR;
    
    /* Cerramos los extremos que no usa el proceso */
    close(pipe_trab2ilust[READ_PIPE]);
    close(pipe_ilust2trab[WRITE_PIPE]);

    /* Bloqueamos todas las senhales menos SIGTERM */
    sigfillset(&set);
	sigdelset(&set, SIGTERM);
    sigdelset(&set, SIGALRM);
    if (sigprocmask(SIG_BLOCK, &set, NULL) < 0) {
        perror("sigprocmask");
        return ERROR;
    }

    /* Manejamos la senhal de la alarma */
    sigemptyset(&(act.sa_mask));
    act.sa_flags = 0;
    act.sa_handler = manejador_sigalarm;
    if (sigaction(SIGALRM, &act, NULL) < 0) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }

    /* Crea la cola de mensajes para poder leer de ella */
    struct mq_attr attributes = {
        .mq_flags = 0,
        .mq_maxmsg = 10,
        .mq_curmsgs = 0,
        .mq_msgsize = 2*sizeof(int)
    };

    mqd_t queue = mq_open(MQ_NAME,
        O_CREAT | O_RDONLY, 
        S_IRUSR | S_IWUSR,
        &attributes);

    if(queue == (mqd_t)-1) {
        fprintf(stderr, "Error opening the queue\n");
        return ERROR;
    }

    /* Establece la alarma */
    if (alarm(SECS)){
        fprintf(stderr, "Existe una alarma previa establecida\n");
    }
    
    while (1){
        /* Inicializa el estado de la tarea que esta realizando */
        estado[0] = getpid();
        estado[1] = -1;
        estado[2] = -1;
        
        /* Lee la tarea de la cola de mansajes */
        if (mq_receive(queue, (char *)pos, 2*sizeof(int), NULL) == -1) {
            if (errno==EINTR && alarma==0){ /* llegada de una señal externa */
                perror("senal recibida");
                mq_close(queue);
                return OK;
            }
            else if (alarma==1){  /* llega la alarma por lo que debe volvere a leer de la cola de mensajes */
                alarma = 0;
                continue;
            }
            else{
                perror("message");
                mq_close(queue);
                return ERROR;
            }
        }

        /* Actualiza la tarea en la que esta trabajando */
        estado[0] = getpid();
        estado[1] = pos[0];
        estado[2] = pos[1];
        task = &(sort->tasks[pos[0]][pos[1]]);

        /* Cambiamos el estado de la tarea a PROCESSING */
        do{     /* si llega la alarma se debe volver a hacer el wait del semaforo */
            alarma=0;
            sem_wait(&(task->mutex)); 
        } while (alarma==1);
        task->completed = PROCESSING;
        sem_post(&(task->mutex));

        /* Se ejecuta la tarea */
        if (solve_task(sort, task) == ERROR){
            fprintf(stderr, "Error solving task\n");
            mq_close(queue);
            return ERROR;
        }
        
        /* Cambiamos el estado de la tarea a COMPLETED */
        do{     /* si llega la alarma se debe volver a hacer el wait del semaforo */
            alarma=0;
            sem_wait(&(task->mutex));
        } while (alarma==1);
        task->completed = COMPLETED;
        sem_post(&(task->mutex));
        
        /* Enviamos la senhal SIGUSR1 al padre para notificar que se ha acabado de realizar la tarea */
        if(kill(sort->ppid, SIGUSR1)){
            perror("kill SIGUSR1");
            mq_close(queue);
            return ERROR;
        }
    }
}

Status ilustrador(Sort* sort){
    int i, j ,k;
    char ready = 'r';
    sigset_t set;
    ssize_t nbytes = 0;
    int tasks[sort->n_processes][3];

    if (sort == NULL)
        return ERROR;

    /* Bloqueo de todas las senhales menos SIGTERM */
    sigfillset(&set);
	sigdelset(&set, SIGTERM);
    if (sigprocmask(SIG_BLOCK, &set, NULL) < 0) {
        perror("sigprocmask");
        return ERROR;
    }

    /* cerrar los descriptores de entrada y salida de las tuberias */
    close(pipe_trab2ilust[WRITE_PIPE]);
    close(pipe_ilust2trab[READ_PIPE]);

    /* Imprimimos el estado inicial del vector */
    plot_vector(sort->data, sort->n_elements);
    printf("\nStarting algorithm with %d levels and %d processes...\n", sort->n_levels, sort->n_processes);

    while (1){
        /* Lee los estados de todos los trabajados por las tuberias */
        for (i = 0; i < sort->n_processes; i++){
            nbytes = read(pipe_trab2ilust[READ_PIPE], tasks[i], 3*sizeof(int));
            if (nbytes == -1){
                perror("read");
                return ERROR;
            }
        }

        /* Mostrar estado del sistema */
        plot_vector(sort->data, sort->n_elements);
        printf("\n%10s%10s%10s%10s%10s\n", "PID", "LEVEL", "PART", "INI", "END");
        for (k = 0; k < sort->n_processes; k++){
            i = tasks[k][1];
            j = tasks[k][2];
            if (i == -1){
                printf("%10d%10d%10d%10d%10d\n", tasks[k][0], -1, -1, \
                    -1, -1);
            }
            else{
                printf("%10d%10d%10d%10d%10d\n", tasks[k][0], i, j, \
                    sort->tasks[i][j].ini, sort->tasks[i][j].end);
            }
        }

        /* Permite a los procesos volver a trabajar */
        for (k = 0; k < sort->n_processes; k++){
            nbytes = write(pipe_ilust2trab[WRITE_PIPE], &ready, sizeof(char));
            if(nbytes == -1){
                perror("write");
                exit(EXIT_FAILURE);
            }
        }
    }
    return OK;
}



Status sort_multiple_processes(Sort* sort) {
    int i, j;
    sigset_t setUsr1;
    alarma=0;

    /****************** COLA DE MENSAJES ******************/
    struct mq_attr attributes = {
        .mq_flags = 0,
        .mq_maxmsg = 10,
        .mq_curmsgs = 0,
        .mq_msgsize = 2*sizeof(int)
    };

    mqd_t queue = mq_open(MQ_NAME,
        O_WRONLY | O_CREAT | O_EXCL, 
        S_IRUSR | S_IWUSR, 
        &attributes);

    if (queue == (mqd_t)-1) {
        fprintf(stderr, "Error opening the queue\n");
        return EXIT_FAILURE;
    }

    /********** TUBERIAS TRABAJADOR - ILUSTRADOR **********/
    if (pipe(pipe_trab2ilust) == -1 || pipe(pipe_ilust2trab) == -1){
        perror("pipe");
        shm_unlink(SHM_NAME);
        mq_unlink(MQ_NAME);
        return EXIT_FAILURE;
    }


    /* Creamos n_processes trabajadores */
    for (j = 0; j < sort->n_processes; j++){
        pids[j] = fork();

        if (pids[j]<0){
            perror("fork");
            return ERROR;
        }
        else if (pids[j] == 0){
            return trabajador(sort);
        }
    }
    
    /* Crear el hijo ilustrador */
    pids[sort->n_processes] = fork();
    pids[sort->n_processes] = pids[sort->n_processes];
    if (pids[sort->n_processes]<0){
        perror("fork");
        return ERROR;
    }
    else if (pids[j] == 0){ 
        return ilustrador(sort);
    }
    

    for (i = 0; i < sort->n_levels; i++) {
        /* Enviamos las tareas a la cola de mensajes */
        for (j = 0; j < get_number_parts(i, sort->n_levels); j++){
            int task[2] = {i, j};
            if (mq_send(queue, (char *)task, 2*sizeof(int), 1) == -1) {
                fprintf(stderr, "Error sending message\n");
                return ERROR;
            }
            else{  /* Actualizamos el estado de la tarea a SENT*/
                sem_wait(&(sort->tasks[i][j].mutex));
                sort->tasks[i][j].completed = SENT;
                sem_post(&(sort->tasks[i][j].mutex));
            }
        }

        /* configuracion de sigsupend */
        sigfillset(&setUsr1);
        sigdelset(&setUsr1, SIGUSR1);
        sigdelset(&setUsr1, SIGINT);

        do{
            /* se suspende el proceso padre hasta que termina algun hijo o recibe SIGINT */
            sigsuspend(&setUsr1);
        }while(check_nivel_completed(sort, i) == FALSE);

        
    }

    /* Mandamos la señal SIGTERM para que terminen los hijos */
    for (j = 0; j <= sort->n_processes; j++){
        if(kill(pids[j], SIGTERM)){
            perror("kill SIGTERM");
            shm_unlink(SHM_NAME);
            mq_unlink(MQ_NAME);
            return ERROR;
        }
    }

    printf("\nAlgorithm completed\n");
    
    /* Liberamos la memoria compartida y la cola de mesajes */
    shm_unlink(SHM_NAME);
    mq_unlink(MQ_NAME);
    return OK;
}
